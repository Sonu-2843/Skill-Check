# Skillcheck
Blockchain technology is one of those technologies which are at an infancy. There is a vast literature which argues that there are ample number of places where Blockchain Technology is yet to
implemented. One of those is the education system. Skill verification is one of those problems which
many recruiters, companies and even professor face when they want to select a few of many. We
propose a blockchain based system where examiner can rely on the scores of a user in a particular
skill which you name on our platform, i.e SkillCheck. This system also conduct the test and get the
top-ranked without taking the effort of checking a large amount of answerscript. In this paper we
present a blockchain based system which can verify skills using examination conducted by various
examiners without doing effort of checking answerscript. We have implemented a blockchain based
portal which reduces the effort of an examiner by crowd-sourcing the task of grading of using an
algorithm that process certain desirably properties against strategic behavior. An allocation algorithm
is presented, which can incentivise evaluators to evaluate exam paper.

### THE PAPER HAS BEEN ACCEPTED BY IEEE ICBC(INTERNATIONAL CONFERENCE ON BLOCKCHAIN AND CRYPTOCURRENCY) 2020

Link to the paper is given: http://arxiv.org/abs/2003.03540
